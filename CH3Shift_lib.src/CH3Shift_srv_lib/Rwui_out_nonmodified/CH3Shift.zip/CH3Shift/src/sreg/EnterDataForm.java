package sreg;

import javax.servlet.http.HttpServletRequest;
import org.apache.struts.action.ActionMessage;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;
import org.apache.struts.upload.FormFile;
import org.apache.struts.upload.MultipartRequestHandler;
import java.lang.reflect.*;
import java.io.File;
import java.util.regex.Pattern;
import sreg.InputDataBean;

/**
 * ActionForm associated with web page for entering data 
 *
 * @author Richard Newton
 */

public  class EnterDataForm extends ActionForm {
    
    public EnterDataForm() { }
    
    private String procFlag;
    public String getProcFlag() {return this.procFlag;}
    public void setProcFlag(String procFlag) { this.procFlag = procFlag;}
    
    public boolean isNumeric(String inputtext){
        boolean isnum = false;
        // check if begins with a number or + or - and has only numbers with perhaps a . and perhaps e or E or + or - and an integer
        isnum = Pattern.matches("\\A\\s*[\\+\\-]?((\\d+)|(\\d+\\.)|(\\d+\\.\\d+)|(\\.\\d+))([eE]{1}[\\+\\-]?(\\d+))?\\s*\\Z", inputtext);
        return isnum;
    }
    
    public boolean isNa(String inputtext){
        boolean isna = false;
        isna = Pattern.matches("\\A\\s*(NA{1})|(Na{1})|(na{1})|(nA{1})\\s*\\Z", inputtext);
        return isna;
    }
    
    public boolean isHex(String inputtext){
	    boolean ishex = false;
	    ishex = Pattern.matches("\\A\\s*[A-F\\d]{15,16}\\s*", inputtext);
	    return ishex;
	}
    
    public boolean isHexZip(String inputtext, String oarappname){
	    boolean ishex = false;
	    ishex = Pattern.matches("\\A\\s*"+ oarappname+"_[A-F\\d]{15,16}\\.zip\\s*", inputtext);
	    return ishex;
	}
    
    public String getTopdir(HttpServletRequest request){
        String os = System.getProperty("os.name").toLowerCase(); 
        String userdir; 
        if(os.indexOf("windows") > -1){  
            userdir = request.getSession().getServletContext().getRealPath("\\"); 
        }else{ 
            userdir = request.getSession().getServletContext().getRealPath("/"); 
        } 
        int indx = userdir.lastIndexOf(File.separator, userdir.length()-2);
        String topdir = userdir.substring(0, indx);
        return topdir;
    }
    
    
    public boolean isText(String inputtext){
        boolean istext = true;
        
        // Uncomment and add a regex if required.
        //boolean istext = false;
        //istext = Pattern.matches("ADD REGEX HERE", inputtext);
        
        return istext;
    }
    
	 private String title; 
	 public String getTitle() {return (this.title);} 
	 public void setTitle(String title) {this.title = title;}
	 private FormFile pdbname; 
	 public FormFile getPdbname() {return (this.pdbname);} 
	 public void setPdbname(FormFile pdbname) {this.pdbname = pdbname;}
	 private String pdbtype; 
	 public String getPdbtype() {return (this.pdbtype);} 
	 public void setPdbtype(String pdbtype) {this.pdbtype = pdbtype;}
	 private String seqshift; 
	 public String getSeqshift() {return (this.seqshift);} 
	 public void setSeqshift(String seqshift) {this.seqshift = seqshift;}
	 private String examine; 
	 public String getExamine() {return (this.examine);} 
	 public void setExamine(String examine) {this.examine = examine;}
	 private FormFile experdata; 
	 public FormFile getExperdata() {return (this.experdata);} 
	 public void setExperdata(FormFile experdata) {this.experdata = experdata;}
	 private boolean rereference; 
	 public boolean getRereference() {return (this.rereference);} 
	 public void setRereference(boolean rereference) {this.rereference = rereference;}

	 private String outorder; 
	 public String getOutorder() {return (this.outorder);} 
	 public void setOutorder(String outorder) {this.outorder = outorder;}
	 private String bias; 
	 public String getBias() {return (this.bias);} 
	 public void setBias(String bias) {this.bias = bias;}

	 private String xlimmin; 
	 public String getXlimmin() {return (this.xlimmin);} 
	 public void setXlimmin(String xlimmin) {this.xlimmin = xlimmin;}
	 private String xlimmax; 
	 public String getXlimmax() {return (this.xlimmax);} 
	 public void setXlimmax(String xlimmax) {this.xlimmax = xlimmax;}

	 private String ylimmin; 
	 public String getYlimmin() {return (this.ylimmin);} 
	 public void setYlimmin(String ylimmin) {this.ylimmin = ylimmin;}
	 private String ylimmax; 
	 public String getYlimmax() {return (this.ylimmax);} 
	 public void setYlimmax(String ylimmax) {this.ylimmax = ylimmax;}
	 private boolean pointlabel; 
	 public boolean getPointlabel() {return (this.pointlabel);} 
	 public void setPointlabel(boolean pointlabel) {this.pointlabel = pointlabel;}
	 private boolean linelabel; 
	 public boolean getLinelabel() {return (this.linelabel);} 
	 public void setLinelabel(boolean linelabel) {this.linelabel = linelabel;}
	 private boolean plotexper; 
	 public boolean getPlotexper() {return (this.plotexper);} 
	 public void setPlotexper(boolean plotexper) {this.plotexper = plotexper;}

	 private String plotheight; 
	 public String getPlotheight() {return (this.plotheight);} 
	 public void setPlotheight(String plotheight) {this.plotheight = plotheight;}
	 private String plotwidth; 
	 public String getPlotwidth() {return (this.plotwidth);} 
	 public void setPlotwidth(String plotwidth) {this.plotwidth = plotwidth;}

	 private String colALA; 
	 public String getColALA() {return (this.colALA);} 
	 public void setColALA(String colALA) {this.colALA = colALA;}
	 private String colVAL; 
	 public String getColVAL() {return (this.colVAL);} 
	 public void setColVAL(String colVAL) {this.colVAL = colVAL;}
	 private String colTHR; 
	 public String getColTHR() {return (this.colTHR);} 
	 public void setColTHR(String colTHR) {this.colTHR = colTHR;}
	 private String colLEU; 
	 public String getColLEU() {return (this.colLEU);} 
	 public void setColLEU(String colLEU) {this.colLEU = colLEU;}
	 private String colILE; 
	 public String getColILE() {return (this.colILE);} 
	 public void setColILE(String colILE) {this.colILE = colILE;}
	 private String colMET; 
	 public String getColMET() {return (this.colMET);} 
	 public void setColMET(String colMET) {this.colMET = colMET;}

	 private String expCOL; 
	 public String getExpCOL() {return (this.expCOL);} 
	 public void setExpCOL(String expCOL) {this.expCOL = expCOL;}
	 private String colALAexp; 
	 public String getColALAexp() {return (this.colALAexp);} 
	 public void setColALAexp(String colALAexp) {this.colALAexp = colALAexp;}
	 private String colVALexp; 
	 public String getColVALexp() {return (this.colVALexp);} 
	 public void setColVALexp(String colVALexp) {this.colVALexp = colVALexp;}
	 private String colTHRexp; 
	 public String getColTHRexp() {return (this.colTHRexp);} 
	 public void setColTHRexp(String colTHRexp) {this.colTHRexp = colTHRexp;}
	 private String colLEUexp; 
	 public String getColLEUexp() {return (this.colLEUexp);} 
	 public void setColLEUexp(String colLEUexp) {this.colLEUexp = colLEUexp;}
	 private String colILEexp; 
	 public String getColILEexp() {return (this.colILEexp);} 
	 public void setColILEexp(String colILEexp) {this.colILEexp = colILEexp;}
	 private String colMETexp; 
	 public String getColMETexp() {return (this.colMETexp);} 
	 public void setColMETexp(String colMETexp) {this.colMETexp = colMETexp;}
	 String fname=""; 
	 int fname_length=0; 
	 String fname_disk=""; 
	 int fname_disk_length=0;
	 int item_server_length=0; 

	 public ActionErrors validate(ActionMapping mapping, HttpServletRequest request){ 
		 request.getSession().setAttribute(Constants.ANALYSIS_FLAG, "running"); 
		 request.getSession().setAttribute( Constants.CANCEL_FLAG, ""); 
		 request.getSession().setAttribute(Constants.CANCELLED_FLAG, ""); 
		 request.getSession().setAttribute( Constants.RSTARTED_FLAG, ""); 
		 request.getSession().setAttribute(Constants.RFINISHED_FLAG, ""); 
		 ActionErrors errors = new ActionErrors(); 
		 InputDataBean idb = new InputDataBean(); 
		 if(request.getSession().getAttribute(Constants.INPUT_DATA) != null){ 
			 idb = (InputDataBean) request.getSession().getAttribute(Constants.INPUT_DATA);} 
		 if(pdbname != null){fname = pdbname.getFileName();} 
		 if(fname != null){fname_length = fname.length();} 
		 if((pdbname == null) || fname == null ||(fname_length < 1)){ 
			 if(idb.getPdbname() != null){ 
				 this.pdbname = idb.getPdbname(); 
			 } 
		 } 
		 fname=""; 
		 fname_length = 0;
		 if(experdata != null){fname = experdata.getFileName();} 
		 if(fname != null){fname_length = fname.length();} 
		 if((experdata == null) || fname == null ||(fname_length < 1)){ 
			 if(idb.getExperdata() != null){ 
				 this.experdata = idb.getExperdata(); 
			 } 
		 } 
		 fname=""; 
		 fname_length = 0;
		 if(!errors.isEmpty()){ 
			 request.getSession().setAttribute(Constants.ANALYSIS_FLAG, ""); 
		} 
		 return errors; 
	} 
 
	 public void reset(ActionMapping mapping, HttpServletRequest request){ 
		 procFlag = "enter"; 
		 title= "";
		 pdbname= null;
		 pdbtype= "";
		 seqshift= "0";
		 examine= "0";
		 experdata= null;
		 this.setRereference(false);

		 outorder= "";
		 bias= "2";

		 xlimmin= "NA";
		 xlimmax= "NA";

		 ylimmin= "NA";
		 ylimmax= "NA";
		 this.setPointlabel(false);
		 this.setLinelabel(false);
		 this.setPlotexper(false);

		 plotheight= "550";
		 plotwidth= "550";

		 colALA= "";
		 colVAL= "";
		 colTHR= "";
		 colLEU= "";
		 colILE= "";
		 colMET= "";

		 expCOL= "";
		 colALAexp= "";
		 colVALexp= "";
		 colTHRexp= "";
		 colLEUexp= "";
		 colILEexp= "";
		 colMETexp= "";
	}
}
