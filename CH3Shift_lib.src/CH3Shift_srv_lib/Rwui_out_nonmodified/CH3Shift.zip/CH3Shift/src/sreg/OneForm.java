package sreg;


import org.apache.struts.action.ActionForm;

/**
 * Form bean 
 *
 * @author Richard Newton
 */
public  class OneForm extends ActionForm {

	public OneForm() { }
	
}
